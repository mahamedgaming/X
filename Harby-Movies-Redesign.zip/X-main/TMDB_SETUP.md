# Harby Movies — TMDB setup

The project can show a live catalogue from TMDB (movies and TV series), search online, load more pages, and fetch credits/details when a title is opened.

## Connect your TMDB key

1. Sign in to TMDB and open **Settings → API**.
2. Because the key was visible in a screenshot shared earlier, regenerate it first.
3. Copy **API Key (v3 auth)** — do not use the long **API Read Access Token (v4 auth)** for this project.
4. Open `src/services/tmdb.ts`.
5. Replace `PASTE_NEW_TMDB_V3_API_KEY_HERE` with the newly generated v3 API key.
6. Commit the change and redeploy the GitHub Pages site.

This is a static GitHub Pages app, so a v3 key placed in browser code is visible to visitors. Use a read-only key and never put passwords, private tokens, or other secrets in this file. For stronger protection, move TMDB requests behind a server-side proxy.

## What updates automatically

- Trending movies and TV shows load when the site opens.
- Search queries are sent to TMDB automatically.
- “Load more” requests the next TMDB page.
- Opening a title fetches its overview, credits, cast and runtime/season count.
- Favorites and saved video links remain stored in the visitor's browser.

TMDB provides discovery metadata and artwork, not movie playback files or streaming links.
