import type { CinemaXMovie } from '../data/cinemaXMovies';

// TMDB v3 API key. This is a public read-only key in a browser app.
// Replace the placeholder with a newly regenerated key from your TMDB account.
const API_KEY = 'PASTE_NEW_TMDB_V3_API_KEY_HERE';
const API_BASE = 'https://api.themoviedb.org/3';
const IMAGE_BASE = 'https://image.tmdb.org/t/p/';

export const isTmdbConfigured = () =>
  Boolean(API_KEY && !API_KEY.includes('PASTE_'));

interface TmdbPage {
  results: Array<Record<string, unknown>>;
  page: number;
  total_pages: number;
}

const genreName = (ids: number[] = []): CinemaXMovie['category'] => {
  if (ids.some((id) => [28, 12, 14, 16, 37].includes(id))) return 'مغامرة';
  if (ids.some((id) => [878, 9648].includes(id))) return 'خيال علمي';
  if (ids.some((id) => [18, 10749, 10751].includes(id))) return 'دراما';
  return 'أكشن';
};

export async function tmdbRequest<T>(
  path: string,
  params: Record<string, string | number> = {},
): Promise<T> {
  if (!isTmdbConfigured()) {
    throw new Error('أضف مفتاح TMDB v3 الجديد في src/services/tmdb.ts');
  }

  const url = new URL(`${API_BASE}${path}`);
  url.searchParams.set('api_key', API_KEY);
  url.searchParams.set('language', 'ar');
  Object.entries(params).forEach(([key, value]) =>
    url.searchParams.set(key, String(value)),
  );

  const response = await fetch(url.toString());
  if (!response.ok) throw new Error(`TMDB API error: ${response.status}`);
  return response.json() as Promise<T>;
}

export function mapTmdbMovie(raw: Record<string, unknown>): CinemaXMovie {
  const mediaType = raw.media_type === 'tv' || raw.first_air_date ? 'tv' : 'movie';
  const date = String(raw.release_date || raw.first_air_date || '');
  const title = String(raw.title || raw.name || 'بدون عنوان');
  const posterPath = raw.poster_path ? String(raw.poster_path) : '';
  const ratingNum = Number(raw.vote_average || 0);
  const genreIds = Array.isArray(raw.genre_ids) ? raw.genre_ids.map(Number) : [];

  return {
    id: Number(raw.id),
    title,
    category: genreName(genreIds),
    year: date ? Number(date.slice(0, 4)) || 0 : 0,
    rating: ratingNum.toFixed(1),
    ratingNum,
    duration: mediaType === 'tv' ? 'مسلسل' : 'غير محدد',
    director: 'يتم تحميل التفاصيل...',
    actors: [],
    image: posterPath
      ? `${IMAGE_BASE}w500${posterPath}`
      : 'https://placehold.co/500x750/101827/ffffff?text=Harby+Movies',
    desc: String(raw.overview || 'لا يتوفر وصف باللغة العربية حاليًا.'),
    posterTheme: 'dune',
    mediaType,
    backdrop: raw.backdrop_path ? `${IMAGE_BASE}w1280${String(raw.backdrop_path)}` : undefined,
  };
}

export async function getTrendingPage(page = 1): Promise<{
  movies: CinemaXMovie[];
  totalPages: number;
}> {
  const data = await tmdbRequest<TmdbPage>('/trending/all/week', { page });
  return {
    movies: data.results
      .filter((item) => item.media_type === 'movie' || item.media_type === 'tv')
      .map(mapTmdbMovie),
    totalPages: data.total_pages,
  };
}

export async function searchTmdb(query: string): Promise<CinemaXMovie[]> {
  const data = await tmdbRequest<TmdbPage>('/search/multi', {
    query,
    include_adult: 'false',
    page: 1,
  });
  return data.results
    .filter((item) => item.media_type === 'movie' || item.media_type === 'tv')
    .map(mapTmdbMovie);
}

export async function getTmdbDetails(movie: CinemaXMovie): Promise<Partial<CinemaXMovie>> {
  const mediaType = movie.mediaType === 'tv' ? 'tv' : 'movie';
  const data = await tmdbRequest<Record<string, unknown>>(
    `/${mediaType}/${movie.id}`,
    { append_to_response: 'credits' },
  );
  const credits = data.credits as
    | { cast?: Array<{ name: string }>; crew?: Array<{ name: string; job: string }> }
    | undefined;
  const director = credits?.crew?.find((person) => person.job === 'Director');
  const cast = (credits?.cast || []).slice(0, 8).map((person) => person.name);
  const runtime = Number(data.runtime || 0);
  const seasons = Number(data.number_of_seasons || 0);

  return {
    director: director?.name || (mediaType === 'tv' ? 'مسلسل تلفزيوني' : 'غير متوفر'),
    actors: cast,
    desc: String(data.overview || movie.desc),
    backdrop: data.backdrop_path ? `${IMAGE_BASE}w1280${String(data.backdrop_path)}` : movie.backdrop,
    duration:
      mediaType === 'tv'
        ? seasons ? `${seasons} مواسم` : 'مسلسل'
        : runtime ? `${Math.floor(runtime / 60)}س ${runtime % 60}د` : 'غير محدد',
  };
}
